cp priceSheet.ini $env:APPDATA\Aquamasters\priceSheet.ini
cp -r .\executables $env:APPDATA\Aquamasters\

# Create Desktop Shortcut
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$HOME\Desktop\billing.lnk")
$DIR = Get-Location
$Shortcut.TargetPath = $DIR.tostring() + "\executables\AquaMasters_Billing_App.exe"
$Shortcut.Save()